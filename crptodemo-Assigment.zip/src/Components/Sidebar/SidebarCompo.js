import React from "react";
import { useState } from "react";
import { Nav } from "react-bootstrap";
import "./SidebarCompo.css";
import { AiOutlineLayout, AiFillGift, AiOutlineLogout } from "react-icons/ai";
import { BsArrowLeftRight, BsGraphUp } from "react-icons/bs";

const SidebarCompo = () => {
  const [isSelected, setIsSelected] = useState("Home");
  const newsselection = (text) => {
    console.log(text);
    setIsSelected(text);
  };
  return (
    <div>
      <Nav className="col-md-1 d-none d-md-block   sidebar">
        <div className="lables">
          <Nav.Link
            className={isSelected === "Home" ? "label-div active" : "label-div"}
            onClick={() => newsselection("Home")}
            to=""
            title="Home"
            style={{ textDecoration: "none" }}
          >
            <div className=" d-flex  mb-3 ">
              <label
                className={
                  isSelected === "Home" ? "labletext_active" : "labletext"
                }
              >
                <AiOutlineLayout />
              </label>
            </div>
          </Nav.Link>

          <Nav.Link
            className={
              isSelected === "Listings" ? "label-div active" : "label-div"
            }
            onClick={() => newsselection("Listings")}
            to=""
            title="Listings"
            style={{ textDecoration: "none" }}
          >
            <div className="d-flex mb-2">
              <label
                className={
                  isSelected === "Listings" ? "labletext_active" : "labletext"
                }
              >
                <AiFillGift />
              </label>
            </div>
          </Nav.Link>
          <Nav.Link
            className={
              isSelected === "BsArrowLeftRight" ? "label-div active" : "label-div"
            }
            onClick={() => newsselection("BsArrowLeftRight")}
            to=""
            title="BsArrowLeftRight"
            style={{ textDecoration: "none" }}
          >
            <div className="d-flex mb-2">
              <label
                className={
                  isSelected === "BsArrowLeftRight" ? "labletext_active" : "labletext"
                }
              >
                  <BsArrowLeftRight />
              </label>
            </div>
          </Nav.Link>
         
          <Nav.Link
            className={
              isSelected === "BsGraphUp" ? "label-div active" : "label-div"
            }
            onClick={() => newsselection("BsGraphUp")}
            to=""
            title="BsGraphUp"
            style={{ textDecoration: "none" }}
          >
            <div className="d-flex mb-2">
              <label
                className={
                  isSelected === "BsGraphUp" ? "labletext_active" : "labletext"
                }
              >
          <BsGraphUp />
              </label>
            </div>
          </Nav.Link>
          <Nav.Link
            className={
              isSelected === "AiOutlineLogout" ? "label-div active" : "label-div"
            }
            onClick={() => newsselection("AiOutlineLogout")}
            to=""
            title="AiOutlineLogout"
            style={{ textDecoration: "none" }}
          >
            <div className="d-flex mb-2">
              <label
                className={
                  isSelected === "AiOutlineLogout" ? "labletext_active" : "labletext"
                }
              >
          <AiOutlineLogout />
              </label>
            </div>
          </Nav.Link>
        
        </div>
      </Nav>
    </div>
  );
};

export default SidebarCompo;
