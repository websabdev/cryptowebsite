import React from "react";
import { Row, Col } from "react-bootstrap";
import Button from "react-bootstrap/Button";
import Card from "react-bootstrap/Card";
import "./AddExchange.css";
import {
  AiOutlineArrowDown,
  AiOutlineArrowUp,
  AiOutlineWallet,AiTwotoneLeftCircle
} from "react-icons/ai";
import progressimg from "../../Assets/Images/progress.png"
import Container from "react-bootstrap/Container";

const AddExchangecomponent = () => {
  return (
    <div className="mt-4 mb-2">
      <Container>
        <Row>
          <Col lg={6} md={6} xs={12}>
            <Card className="card-div">
              <Card.Body>
                <div className="btcdiv">2.43454 BTC</div>

                <div className="d-flex">
                  <Card.Title>
                    <AiOutlineWallet />
                    Balance
                  </Card.Title>
                </div>
                <div>
                  $ <span className="moneydiv">25,200.97</span>
                </div>
                <Row>
                  <Col>
                    <div>
                      <div>
                        <AiOutlineArrowDown /> invested
                      </div>
                      <div>
                        <h4> $10,458.00</h4>
                      </div>
                    </div>
                  </Col>
                  <Col>
                    <div>
                      <div>
                        <AiOutlineArrowUp /> % Profit
                      </div>
                      <div>
                        <h4> + 60%</h4>
                      </div>
                    </div>
                  </Col>
                  <Col>
                    <div>
                      <div>
                        <AiOutlineArrowUp /> USD profit
                      </div>
                      <div>
                        <h4> $15,648.38</h4>
                      </div>
                    </div>
                  </Col>
                </Row>
                <Button className="mt-2" variant="outline-primary">
                  Add Exchange
                </Button>
              </Card.Body>
            </Card>
          </Col>
          <Col lg={6} md={6} xs={12}>
          <Card className="card-div">
           
              <Card.Body>
                <Row>
                    <Col lg={4}>
               <img className="progressimg" src={progressimg}/>
               </Col>
               <Col lg={8}>
              <div>
                <AiTwotoneLeftCircle className="bitocoindiv"/> BitCoin
                <h6>$7,467.00</h6>
              </div>
              <div>
                <AiTwotoneLeftCircle className="Etherumdiv"/> Etherum
                <h6>$11,567.00</h6>
              </div>
              <div>
                <AiTwotoneLeftCircle className="Monerodiv"/> Monero
                <h6>$18,758.00</h6>
              </div>
               </Col>
               </Row>
              </Card.Body>
            </Card>
          </Col>
        </Row>
      </Container>
    </div>
  );
};

export default AddExchangecomponent;
