
import React from 'react'
import Container from 'react-bootstrap/Container';
import Navbar from 'react-bootstrap/Navbar';
import { AiOutlineInfoCircle } from 'react-icons/ai';
import Button from  "react-bootstrap/Button"
import"./Header.css"
const Header = () => {
  return (
    <div className='pt-5'>

      <Container>
      <Navbar bg="white" expand="sm">
        <div className='d-flex'>
        <Navbar.Brand className=""href="#home"> <div><AiOutlineInfoCircle  className='m-2'/>Exchange Not Connected</div></Navbar.Brand>
        </div>
        <Navbar.Toggle /> 
        <Navbar.Collapse className="justify-content-end">
          <Navbar.Text className='px-5'>
          Trial Subsription -7 more days left <Button variant='outline-primary'> Renew Subscription</Button>
          </Navbar.Text>
        </Navbar.Collapse>

    </Navbar>
    </Container>
    </div>
  )
}

export default Header;