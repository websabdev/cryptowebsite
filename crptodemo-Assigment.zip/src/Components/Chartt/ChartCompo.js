import React from "react";
import CanvasJSReact from "../../Assets/canvasjs-3.6.7/canvasjs.react";
import "./ChartCompo.css";
import Container from "react-bootstrap/Container";
import { Row, Col } from "react-bootstrap";
import Card from "react-bootstrap/Card";
import { FcMoneyTransfer } from "react-icons/fc";

import { BsFillArrowDownCircleFill,BsFillArrowUpCircleFill } from "react-icons/bs";
import Button from "react-bootstrap/Button";
//var CanvasJSReact = require('./canvasjs.react');
var CanvasJS = CanvasJSReact.CanvasJS;
var CanvasJSChart = CanvasJSReact.CanvasJSChart;
class ChartCompo extends React.Component {
  render() {
    const options = {
      title: {
        text: "Basic Column Chart in React",
      },
      data: [
        {
          type: "column",
          dataPoints: [
            { label: "one-day", y: 10 },
            { label: "one-week", y: 15 },
            { label: "one-month", y: 25 },
            { label: "six-month", y: 30 },
            { label: "one-year", y: 28 },
          ],
        },
      ],
    };

    return (
      <div className="mt-5">
        <Container>
          <Row>
            <Col lg={8}>
              <CanvasJSChart className="canvasdiv" options={options} />
            </Col>
            <Col lg={4}>
              <div>
                <Card>
                  <div className="carddivpad">
                    <Row>
                      <Col lg={6}>
                        <FcMoneyTransfer />
                        Trasactions{" "}
                      </Col>
                      <Col lg={6}>
                        <div className="seeAllbtn">
                          <Button variant="warning">See All</Button>
                        </div>
                      </Col>
                      <Col lg={6}>
                       
                 <div className="pt-3"> <BsFillArrowDownCircleFill /> Buy
                   <h5> $250.00</h5>
                 </div>
                      </Col>
                      <Col lg={6}>
                        <div className="seeAllbtn pt-3">
                        August 11,2022
                        </div>
                      </Col>
                      <Col lg={6}>
                       
                      <div className="pt-3"><BsFillArrowUpCircleFill /> Sell
                   <h5> $250.00</h5>
                 </div>
                            </Col>
                            <Col lg={6}>
                            <div className="seeAllbtn pt-3">
                              August 11,2022
                              </div>
                            </Col>
                            <Col lg={6}>
                       
                            <div className="pt-3"> <BsFillArrowUpCircleFill /> Sell
                   <h5> $250.00</h5>
                 </div>
                            </Col>
                            <Col lg={6}>
                              <div className="seeAllbtn pt-3">
                              August 11,2022
                              </div>
                            </Col>
                    </Row>
                  </div>
                </Card>
              </div>
            </Col>
          </Row>
        </Container>
      </div>
    );
  }
}
export default ChartCompo;
