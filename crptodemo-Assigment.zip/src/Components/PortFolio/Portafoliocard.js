import React from 'react'
import Container from "react-bootstrap/Container";


import portfoilio3 from "../../Assets/Images/portfolio3.webp"
import{Row,Col} from "react-bootstrap"
import "./Portafoliocard.css"
const Portafoliocard = () => {
  return (
    <div className='mt-3'>
        <Container>
<Row>
<Col lg={4}>
    <div className='img-div'>
    <h5 className='p-2'>Portfolio-1</h5>
<img className='portfolioimg img-fluid' src={portfoilio3}/>
    </div>

</Col>
<Col lg={4}>
<div className='img-div '>
<h5 className='p-2'>Portfolio-2</h5>
<img className='portfolioimg img-fluid' src={portfoilio3}/>
    </div>

</Col>
<Col lg={4}>
<div className='img-div'>
<h5 className='p-2'>Portfolio-3</h5>
<img className='portfolioimg img-fluid' src={portfoilio3}/>
    </div>

</Col>
</Row>
        </Container>
    </div>
  )
}

export default Portafoliocard;