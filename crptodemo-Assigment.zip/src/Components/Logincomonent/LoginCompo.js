


import React from 'react'
import {Row,Col,Card,Button,Form} from "react-bootstrap"
import developer from "../../Assets/Images/developer.jpg"
import {useNavigate} from "react-router-dom"
import "./LoginCompo.css"
const LoginCompo = () => {
const navigate=useNavigate()
    const Gotohome=()=>{
navigate('/cryptohome')
    }
  return (
    <div className='container text-center logindiv'>
              <h2 className='contactheading pt-10'> Welcome To CryptoCurrency Website</h2>
              
        <Row>
            <Col lg={6} xs={12}>
         <div>
            <img className='img-fluid developerimg' src={developer}/>
         </div>
            </Col>
            <Col lg={6} xs={12}>
            <div className='card-div '>

            <Form>
      <Form.Group className="mb-3" controlId="formBasicEmail">
        <Form.Label className='lable'>Email address</Form.Label>
        <Form.Control type="email" placeholder="Enter email"  required/>
        <Form.Text className="text-muted">
          We'll never share your email with anyone else.
        </Form.Text>
      </Form.Group>

      <Form.Group className="mb-3" controlId="formBasicPassword">
        <Form.Label className='lable'>Password</Form.Label>
        <Form.Control type="password" placeholder="Password" required/>
      </Form.Group>
      <Form.Group className="mb-3 mr-2" controlId="formBasicCheckbox">
        <Form.Check className='lable ml-2' type="checkbox" label="Check me out" />
      </Form.Group>
      <Button className='lable' variant="success" type="submit" onClick={Gotohome}>
        Submit
      </Button>
    </Form>

            </div>  
            </Col>
        </Row>
    </div>
  )
}

export default LoginCompo;