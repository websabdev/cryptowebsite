import React from 'react'
import AddExchangecomponent from '../AddExchangecard.js/AddExchangecomponent';
import ChartCompo from '../Chartt/ChartCompo';
import Header from '../Header/Header';
import Portafoliocard from '../PortFolio/Portafoliocard';

const MiddleContent = () => {
  return (
    <div className='container'>
<div>
        <Header/>
        <AddExchangecomponent/>
        <Portafoliocard/>
        <ChartCompo/>
        </div>
    </div>
  )
}

export default MiddleContent;