import React from 'react'
import "./RecentActivity.css"
import { BsArrowDownUp} from 'react-icons/bs';
import { AiOutlineArrowUp} from 'react-icons/ai';
const RecentActivity = () => {
  return (
    <div className='container p-5'>
        <div className='d-flex'>
       <BsArrowDownUp/> <h6 className='px-2 Btcdiv'>Recent Activity</h6>

       </div>
       <div className='d-flex pt-3'>
       <AiOutlineArrowUp/> <h6 className='px-2 Btcdiv'>18,37 USD= 0.84 BTC</h6>

       </div>
       <h6 className='px-4'>1 BTC =8468 BTC</h6>
       <div className='d-flex pt-3'>
       <AiOutlineArrowUp/> <h6 className='px-2 Btcdiv'>18,37 USD= 0.84 BTC</h6>
       </div>
       <h6 className='px-4'>1 BTC =8468 BTC</h6>
       <div className='d-flex pt-3'>
       <AiOutlineArrowUp/> <h6 className='px-2 Btcdiv'>18,37 USD= 0.84 BTC</h6>
       </div>
       <h6 className='px-4'>1 BTC =8468 BTC</h6>
       <hr></hr>
    </div>
  )
}

export default RecentActivity;