import React from "react";
import "./ProfileRightsideBar.css";
import { Nav } from "react-bootstrap";
import { Row, Col } from "react-bootstrap";
import musk from "../../Assets/Images/musk.jpg";
import RecentActivity from "./RecentActivity";
import ExchangeUsd from "./ExchangeUsd";
const ProfileRightsideBar = () => {
  return (
    <div className="">
      <Nav className="col-md-1 d-none d-md-block  rightsidebar">
        <Row>
          <div className="d-flex">
            <img className="profileimg px-2" src={musk} />
            <div className="pt-2">
              <h6>Good Morning, Musk</h6>
              <h6 className="settings">Settings</h6>
            </div>
          </div>
          <RecentActivity/>
          <ExchangeUsd/>
        </Row>
      </Nav>
    </div>
  );
};

export default ProfileRightsideBar;
