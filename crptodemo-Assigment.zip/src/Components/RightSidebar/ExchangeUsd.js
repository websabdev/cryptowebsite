import React from "react";
import "./ExchangeUsd.css";
import envelope from  "../../Assets/Images/envelope.png"
import { TiArrowRepeatOutline } from "react-icons/ti";
import Dropdown from "react-bootstrap/Dropdown";
import Button from 'react-bootstrap/Button';
const ExchangeUsd = () => {
  return (
    <div className="container px-5">
      <div className="d-flex">
   <div className="p-1">     <TiArrowRepeatOutline className="exchangeimg"/></div>
      
        <h6 className="p-2"> Exchange</h6>
      
        <div className="dropdown-div">
          <Dropdown className="dropdown-div">
            <Dropdown.Toggle variant="success" id="dropdown-basic">
              USD
            </Dropdown.Toggle>

            <Dropdown.Menu>
              <Dropdown.Item href="#/action-1">$454</Dropdown.Item>
              <Dropdown.Item href="#/action-2">$454</Dropdown.Item>
              <Dropdown.Item href="#/action-3">$654</Dropdown.Item>
            </Dropdown.Menu>
          </Dropdown>
        </div>
      </div>
      <div className="pt-5">
      <h6 className="Usddiv ">17,0000 USD </h6>
 
      
      <h6 className="Usddiv1 mb-2 ">17,0000 USD</h6>
    </div> 
    <div className="pt-5">

    <div className="envelope">
    <img className="envelopepimg" src={envelope}/>
        <h5>Invite Customer and</h5>
        <h6> get $ 10 for each</h6>
        <Button variant="outline-warning"> Send Notification</Button>
        </div>
    </div>
    </div>
  );
};

export default ExchangeUsd;
