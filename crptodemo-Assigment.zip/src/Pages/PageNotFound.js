import React from 'react'
import PageNotFoundimg from "../Assets/Images/pagenotfound.webp"
const PageNotFound = () => {
  return (
    <div className=''>
      <img src={PageNotFoundimg}/>
    </div>
  )
}

export default PageNotFound;