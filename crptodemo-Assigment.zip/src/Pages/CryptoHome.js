import React from 'react'
import MiddleContent from '../Components/MiddleContent/MiddleContent';
import ProfileRightsideBar from '../Components/RightSidebar/ProfileRightsideBar';
import SidebarCompo from '../Components/Sidebar/SidebarCompo';
import "./CryptoHome.css"
const CryptoHome = () => {
  return (
    <div className='CryptoHome-div'>
        <div className='d-flex'>
        <SidebarCompo/>
        <MiddleContent/>
        <ProfileRightsideBar/>
        </div>
      

    </div>
  )
}

export default CryptoHome;