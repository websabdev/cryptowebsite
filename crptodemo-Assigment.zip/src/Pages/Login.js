import React from 'react'
import LoginCompo from '../Components/Logincomonent/LoginCompo';

const Login = () => {
  return (
    <div>
        <LoginCompo/>
    </div>
  )
}

export default Login;