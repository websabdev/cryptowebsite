
import './App.css';
import RouteCompo from './Routes/RouteCompo';

function App() {
  return (
    <div>
   <RouteCompo/>
    </div>
  );
}

export default App;
