import React from 'react'
import { BrowserRouter, Routes, Route } from "react-router-dom";
import CryptoHome from '../Pages/CryptoHome';
import Login from '../Pages/Login';
import PageNotFound from '../Pages/PageNotFound';

const RouteCompo = () => {
  return (
    <div>
         <BrowserRouter>
      <Routes>
        <Route exact path="/CryptoHome" element={<CryptoHome />}/>
        <Route exact path="/" element={<Login />}>
          <Route exact path="*" element={<PageNotFound />} />
        </Route>
      </Routes>
    </BrowserRouter>
    </div>
  )
}

export default RouteCompo;