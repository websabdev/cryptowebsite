<!-- Hello welcome to the cryptocurrency webstite template
this website is made using react js laibrary and bootstratp frmaework 
to run this website 
-install node modules
-open terminal and run command as  ---------- npm start---------------

 -->